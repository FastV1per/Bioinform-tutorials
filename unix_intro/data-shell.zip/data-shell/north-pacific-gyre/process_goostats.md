# Goostats script
: ex: set ft=markdown ;:<<'```bash' #


The following code block loops through all files in `2012-07-03/*.txt`, runs each through `goostats` and saves the output in the `output/` folder.

As it goes, it prints out the sampleID currently being processed

```bash
for data_file in 2012-07-03/*.txt
do    
    sample_name=$(basename -s .txt $data_file)    
    echo $sample_name
    programs/goostats ${data_file} > output/${sample_name}.out
done 
:<<'```bash' #
```

Note above that we end the bash block with `:<<'```bash' #`. This is necessary so that this text is skipped and bash moves to the next code block!

```bash
echo Processing is done!
:<<'```bash' #
```